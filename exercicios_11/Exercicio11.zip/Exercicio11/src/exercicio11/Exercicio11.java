/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package exercicio11;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.security.KeyStore;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.cert.Certificate;
import java.security.cert.CertificateException;
import java.security.cert.X509Certificate;

/**
 *
 * @author leoro
 */
public class Exercicio11 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws KeyStoreException, FileNotFoundException, IOException, NoSuchAlgorithmException, CertificateException {
        KeyStore keystore = KeyStore.getInstance("JKS");
        keystore.load(new FileInputStream("C:\\Users\\leoro\\OneDrive\\Área de Trabalho\\ \\Furb\\6° Semestre\\Sistemas Seguros\\bcc_2019_2_SisSeg\\exercicios_11\\Furb"), "furb".toCharArray());

        Certificate certificate = keystore.getCertificate("*.furb.br (icpedu)");
        X509Certificate x509Cert = (X509Certificate) certificate;
        System.out.println("Proprietario =  " + x509Cert.getSubjectDN());
        System.out.println("Emissor = " + x509Cert.getIssuerDN());
        System.out.println("É auto-assinado = " + verifcarAutoAssinado(x509Cert));

        System.out.println("----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------");
        Certificate certificate2 = keystore.getCertificate("gilvan justino");
        X509Certificate x509Cert2 = (X509Certificate) certificate2;
        System.out.println("Proprietario =  " + x509Cert2.getSubjectDN());
        System.out.println("Emissor = " + x509Cert2.getIssuerDN());
        System.out.println("É auto-assinado = " + verifcarAutoAssinado(x509Cert2));

        System.out.println("----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------");
        Certificate certificate3 = keystore.getCertificate("www.angeloni.com.br (go daddy secure certificate authority - g2)");
        X509Certificate x509Cert3 = (X509Certificate) certificate3;
        System.out.println("Proprietario =  " + x509Cert3.getSubjectDN());
        System.out.println("Emissor = " + x509Cert3.getIssuerDN());
        System.out.println("É auto-assinado = " + verifcarAutoAssinado(x509Cert3));

        System.out.println("----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------");
        Certificate certificate4 = keystore.getCertificate("www.guiadoestudante.abril.com.br (let's encrypt authority x3)");
        X509Certificate x509Cert4 = (X509Certificate) certificate4;
        System.out.println("Proprietario =  " + x509Cert4.getSubjectDN());
        System.out.println("Emissor = " + x509Cert4.getIssuerDN());
        System.out.println("É auto-assinado = " + verifcarAutoAssinado(x509Cert4));
    }

    public static boolean verifcarAutoAssinado(X509Certificate certificado) {
        return certificado.getIssuerDN().equals(certificado.getSubjectDN());
    }

}
